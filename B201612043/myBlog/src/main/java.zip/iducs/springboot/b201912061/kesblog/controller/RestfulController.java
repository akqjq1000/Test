package iducs.springboot.b201912061.kesblog.controller;

public class RestfulController {
}
