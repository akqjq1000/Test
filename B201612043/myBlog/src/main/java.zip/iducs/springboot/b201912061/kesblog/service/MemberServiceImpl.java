package iducs.springboot.b201912061.kesblog.service;

import iducs.springboot.b201912061.kesblog.domain.Member;
import iducs.springboot.b201912061.kesblog.repository.MemberRepository;
import iducs.springboot.b201912061.kesblog.repository.MemberRepositorylmpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberServiceImpl implements MemberService{
    MemberRepository memberRepository;
    public MemberServiceImpl() {
        memberRepository = new MemberRepositorylmpl();
    }

    @Override
    public Member getMember(long id) {
        return null;
    }

    @Override
    public Member getMemberByEmail(String email) {
        Member member = new Member();
        member.setEmail(email);
        return memberRepository.readByEmail(member);
    }

    @Override
    public List<Member> getMembers() {
        return null;
    }

    @Override
    public List<Member> getMembersByPage(int index, int size) {
        return null;
    }

    @Override
    public int postMember(Member member) {
        return 0;
    }

    @Override
    public int putMember(Member member) {
        return 0;
    }

    @Override
    public int deleteMember(Member member) {
        return 0;
    }
}
