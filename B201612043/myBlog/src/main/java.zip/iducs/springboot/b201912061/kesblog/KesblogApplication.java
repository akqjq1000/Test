package iducs.springboot.b201912061.kesblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KesblogApplication {

    public static void main(String[] args) {
        SpringApplication.run(KesblogApplication.class, args);
    }

}
